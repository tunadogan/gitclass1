#!/usr/bin/env python
# coding: utf-8

# In[2]:


def asal_mı(x):
    i = 2
    while i*i <= x:
        if x % i == 0:
            return False
        i += 1
    else:
        return True


# In[ ]:




