#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def factor(x):

    result = 1
    for i in range(x):
        result *= (i+1)
    return print(result)

